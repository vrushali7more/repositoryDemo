package stepDefinition;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import cucumber.api.java.After;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class SmokeTestCopi {
	
	
	WebDriver driver;

	
	@Given("^Open google chrome and start application$")
	public void open_google_chrome_and_start_application() throws Throwable {
		
		System.setProperty("webdriver.chrome.driver", "F:\\chrome\\chromedriver_win32\\chromedriver.exe");
		driver= new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("http://sales-board-dev.centricsoftware.com/login");
	    
	}

	@When("^I enter valid \"([^\"]*)\" and valid \"([^\"]*)\"$")
	public void i_enter_valid_and_valid(String uname, String pass) throws Throwable {
		
		driver.findElement(By.id("username")).sendKeys(uname);
		driver.findElement(By.id("password")).sendKeys(pass);
	   
	}

	@Then("^user should be able to login successfully$")
	public void user_should_be_able_to_login_successfully() throws Throwable {
		driver.findElement(By.xpath("//span[text()='LOGIN']")).click();
		Thread.sleep(4000);
	}
	
	@When("^user will select buying session from dropdown$")
	public void user_will_select_buying_session_from_dropdown() throws Throwable {
		driver.findElement(By.xpath("//*[@id=\"root\"]/div[2]/div/div/div[2]/div/div/div/div/div")).click();
		Select valBuying = new Select(driver.findElement(By.xpath("//*[@id=\"root\"]/div[2]/div/div/div[2]/div/div/div/div/div")));
		Thread.sleep(2000);
		valBuying.selectByVisibleText("autumn 2002 women shoes");
	}

	@Then("^user should click go button$")
	public void user_should_click_go_button() throws Throwable {
		driver.findElement(By.xpath("//span[text()='GO']")).click();
	}
	

	@After
	public void tearDown() {
		driver.quit();
	}
}
