package com.assignment.qa.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.assignment.qa.base.TestBase;

public class DashboardPage extends TestBase {
	
	@FindBy(id="menu_directory_viewDirectory")
	WebElement directoryLink;

	@FindBy(id="menu_pim_viewPimModule")
	WebElement PIMLink;
	
	@FindBy(id="menu_pim_addEmployee")
	WebElement addEmployeeLink;

	
	public DashboardPage() {
		PageFactory.initElements(driver, this);
	}
	
	public String validateDashboardPageTitle() {
		return driver.getTitle();
		}
	
	
	public DirectoryPage clickOnDirectoryLink() {
		directoryLink.click();
		return new DirectoryPage();
	}
	
	public PIMPage clickOnPIMLink() {
		PIMLink.click();
		return new PIMPage();
	}

	
	public void clickOnNewEmployeeLink() {
		Actions action = new Actions(driver);
		action.moveToElement(PIMLink).build().perform();
		addEmployeeLink.click();
	}
	

}
