package com.assignment.qa.pages;



import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.assignment.qa.base.TestBase;

public class LoginPage extends TestBase {
	
	//Page factory
	@FindBy(name="txtUsername")
	WebElement username;
	
	@FindBy(name="txtPassword")
	WebElement password;
	
	@FindBy(name="Submit")
	WebElement loginBtn;
	

	public LoginPage() {
		PageFactory.initElements(driver, this);
	}
	
	//Actions:
	
	public String validateLoginPageTitle() {
		return driver.getTitle();
		}
	
	public DashboardPage login(String userName,String passWord) {
		username.sendKeys(userName);
		password.sendKeys(passWord);
		loginBtn.click();
		
		return new DashboardPage();
	}
	
}
