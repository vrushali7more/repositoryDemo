package com.assignment.qa.pages;

import java.util.Map;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.assignment.qa.base.TestBase;

public class PIMPage extends TestBase{
	
	
	@FindBy(id = "menu_pim_viewPimModule")
	WebElement pimLabel;
	
	@FindBy(id = "firstName")
	WebElement firstName;
	
	@FindBy(id = "lastName")
	WebElement lastName;
	
	@FindBy(xpath = "//input[@type ='button' and @value='Save']")
	WebElement saveBtn;

	public PIMPage() {
		PageFactory.initElements(driver, this);
	}
	
	
	public boolean verifyPIMLabel() {
		return pimLabel.isDisplayed();
	}
	
	public void createNewEmployee(Map mapData) {
		System.out.println("-----------"+mapData);
		firstName.sendKeys(mapData.get("firstname").toString());
		lastName.sendKeys(mapData.get("lastname").toString());
		saveBtn.click();
	}

}
