package com.assignment.qa.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.assignment.qa.base.TestBase;

public class DirectoryPage extends TestBase{

	@FindBy(id = "searchResults")
	WebElement searchLabel;
	
	public DirectoryPage() {
		PageFactory.initElements(driver,this);
	}
	
	public boolean verifyDirectoryLabel() {
		return searchLabel.isDisplayed();
	}
}
