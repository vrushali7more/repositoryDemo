package com.qa.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.io.FileUtils;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

import com.assignment.qa.base.TestBase;

public class TestUtil extends TestBase{
	
	public Map<Object, Object> datamap;
	
	Object[][] dataset;
	
	public TestUtil() {
	//	this.rowdatamap = new HashMap<String, String>();
	}
	
	public Object[][] readExcel(String filePath,String fileName,String sheetName) {
		File file = new File(filePath +"//"+fileName );
		
		try {
			FileInputStream fileInputStream = new FileInputStream(file);
			
			Workbook workbook = null;
			
			String fileExt = fileName.substring(fileName.indexOf("."));
			
			if(fileExt.equals(".xlsx")) {
				workbook = new XSSFWorkbook(fileInputStream);
			} else if(fileExt.equals(".xls")) {
				workbook = new HSSFWorkbook(fileInputStream);
			}
			
			Sheet sheet = workbook.getSheet(sheetName);
			

			int rowCount = sheet.getLastRowNum();
			int colCount = sheet.getRow(0).getLastCellNum();
			
			dataset = new Object[rowCount][1];
			
			for(int i=0; i < rowCount; i++)
			{
				datamap = new HashMap<Object,Object>();
				 
				for(int j=0 ; j < colCount; j++)
				{
					datamap.put(sheet.getRow(0).getCell(j).toString(), sheet.getRow(i+1).getCell(j).toString());
				}
				dataset[i][0] = datamap;
			}
		} 
		catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		}
		return dataset;
	}
	
	public static void takeScreenshotAtEndOfTest() throws IOException {
		File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		String currentDir = System.getProperty("user.dir");
		FileUtils.copyFile(scrFile, new File(currentDir + "/screenshots/" + System.currentTimeMillis() + ".png"));
	}
	
}
