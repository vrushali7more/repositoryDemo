package com.assignment.qa.testcases;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.assignment.qa.base.TestBase;
import com.assignment.qa.pages.DashboardPage;
import com.assignment.qa.pages.DirectoryPage;
import com.assignment.qa.pages.LoginPage;

public class DirectoryPageTest extends TestBase{

	LoginPage loginPage;
	DashboardPage dashboardPage;
	DirectoryPage directoryPage;
	
	public DirectoryPageTest() {
		super();
	}
	
	
	@BeforeMethod
	public void setUp() {
		initialization();
		loginPage = new LoginPage();
		directoryPage = new DirectoryPage();
		dashboardPage =loginPage.login(prop.getProperty("username"),prop.getProperty("password"));
		directoryPage = dashboardPage.clickOnDirectoryLink();
	}
	
	
		
	@Test
	public void verifyDirectoryPageLabel() {
		Assert.assertTrue(directoryPage.verifyDirectoryLabel(),"Directory label missing");
	}

	@AfterMethod
	public void tearDown() {
		driver.quit();
	}
}
