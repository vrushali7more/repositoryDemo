package com.assignment.qa.testcases;

import java.util.Map;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.assignment.qa.base.TestBase;
import com.assignment.qa.pages.DashboardPage;
import com.assignment.qa.pages.LoginPage;
import com.assignment.qa.pages.PIMPage;
import com.qa.util.TestUtil;

public class PIMPageTest extends TestBase{

	
	LoginPage loginPage;
	DashboardPage dashboardPage;
	PIMPage pimPage;
	TestUtil utilTest;
	String filePath=System.getProperty("user.dir") +"\\src\\main\\java\\com\\qa\\testdata";

	
	public PIMPageTest() {
		
		super();
	}
	
	
	@BeforeMethod
	public void setUp() {
		initialization();
		utilTest = new TestUtil();
		pimPage = new PIMPage();
		loginPage = new LoginPage();
		dashboardPage =loginPage.login(prop.getProperty("username"),prop.getProperty("password"));
		pimPage = dashboardPage.clickOnPIMLink();
	}
	
	@Test(priority=1)
	public void verifyPIMPageLabel() {
		Assert.assertTrue(pimPage.verifyPIMLabel(),"Directory label missing");
	}

	@DataProvider
	public Object[][] getOrangeHrmTestData() {
		TestUtil utilTest = new TestUtil(); 
		 Object[][] arrayObject = utilTest.readExcel(filePath,"OrangeHrmTestData.xlsx","employees" );
		return arrayObject;
	}
	
	
	@Test(priority=2 , dataProvider = "getOrangeHrmTestData")
	public void validateCreateNewEmployee(Map mapData) {
		dashboardPage.clickOnNewEmployeeLink();
		pimPage.createNewEmployee(mapData);
	}
	
	@AfterMethod
	public void tearDown() {
		driver.quit();
	}
}
