package StepDefination;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;


import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Search {
	//public static WebDriver driver;
	Login l1 = new Login();
	@Given("^User is logged into the application$")
	public void user_is_logged_into_the_application() throws Throwable {
		Thread.sleep(3000);
	
	}
	
	@Then("^On dashboard click on Search icon$")
	public void on_dashboard_click_on_Search_icon() throws Throwable {
		System.out.println("in search");
		Thread.sleep(6000);
		 l1.driver.findElement(By.xpath("//img[(@class='addressImg')]")).click();
		 
	}


	@And("^On search page type the location in the search box$")
	public void on_search_page_type_the_location_in_the_search_box() throws Throwable {
		Thread.sleep(3000);
		l1.driver.findElement(By.className("searchBarBox")).click();
		WebElement searchText = l1.driver.findElement(By.xpath("//input[@placeholder='Search places..']"));
		searchText.sendKeys("Houston");
	}

	@And("^Select the location from the drop down list$")
	public void select_the_location_from_the_drop_down_list() throws Throwable {
		Thread.sleep(3000);
		 l1.driver.findElement(By.xpath("//input[@placeholder='Search places..']")).sendKeys(Keys.DOWN);
		 l1.driver.findElement(By.xpath("//input[@placeholder='Search places..']")).sendKeys(Keys.ENTER);
	   
	}

	@Then("^See data on the dashboard$")
	public void see_data_on_the_dashboard() throws Throwable {
	   	Thread.sleep(3000);
		String displaySearchText = l1.driver.findElement(By.xpath("//span[@class='address selectedAddressText']")).getText();
		assertEquals(displaySearchText,"Houston, TX, USA");
		l1.driver.quit();
		}
	

}
