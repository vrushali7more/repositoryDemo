package StepDefination;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Login {
	
	public static WebDriver driver;
	
	@Given("^Open google chrome and start application$")
	public void open_google_chrome_and_start_application() throws Throwable {
		System.setProperty("webdriver.chrome.driver","F:\\chrome\\chromedriver_win32\\chromedriver.exe");
        driver = new ChromeDriver();
        driver.manage().window().maximize();
		driver.get("https://dev.alertnest.com/login");
	  //  throw new PendingException();
	}

	@When("^I enter valid username and valid password$")
	public void i_enter_valid_username_and_valid_password() throws Throwable {
		 WebElement username =  driver.findElement(By.id("login_uname"));
		 username.sendKeys("vrushali");
		 WebElement password =  driver.findElement(By.id("login_pwd"));
		 password.sendKeys("vrushali");
	   // throw new PendingException();
	}

	@Then("^user should be able to login successfully$")
	public void user_should_be_able_to_login_successfully() throws Throwable {
		driver.findElement(By.id("loginBtn")).click();
	//	driver.quit();
	   // throw new PendingException();
	}
}
	