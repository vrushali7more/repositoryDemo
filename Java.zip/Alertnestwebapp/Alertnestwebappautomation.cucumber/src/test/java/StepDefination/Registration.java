package StepDefination;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Registration {
	
	WebDriver driver;
	
	@Given("^Open Chrome and start application.$")
	public void Open_Chrome_and_start_application() throws Throwable {
		System.setProperty("webdriver.chrome.driver","F:\\chrome\\chromedriver_win32\\chromedriver.exe");
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://dev.alertnest.com/");
        
        
       WebElement link;
        link = driver.findElement(By.xpath("//b[contains(text(),'SIGN IN')]"));
        Thread.sleep(5000);
        link.click();
        Thread.sleep(5000);
		driver.findElement(By.linkText("Create a new Account")).click();
    
        
	}

	@When("^Valid input should be entered in all the mandatory fields\\.$")
	public void valid_input_should_be_entered_in_all_the_mandatory_fields() throws Throwable {
		
		System.out.println("in method 1");
		
		Thread.sleep(6000);
		 WebElement Email =  driver.findElement(By.id("signup_email"));
		 Email.sendKeys("vrushali.more@synerzip.com");
		 WebElement username =  driver.findElement(By.id("signup_uname"));
		 username.sendKeys("vrushali1");
		 WebElement password =  driver.findElement(By.id("signup_pwd"));
		 password.sendKeys("vrushali1");
		 Select selecttype = new Select(driver.findElement(By.id("formBasicAddressType")));
		 selecttype.selectByVisibleText("Home");
		
		   driver.findElement(By.xpath("//input[@placeholder='Enter Address or Location']")).sendKeys("Seattle,WA,USA");
		   Thread.sleep(3000);
		   driver.findElement(By.xpath("//input[@placeholder='Enter Address or Location']")).sendKeys(Keys.DOWN);
		   driver.findElement(By.xpath("//input[@placeholder='Enter Address or Location']")).sendKeys(Keys.ENTER);
		  
	     	 
	}

	@Then("^User should be able to login successfully.$")
	public void User_should_be_able_to_login_successfully() throws Throwable {
		System.out.println("in method 2");
		Thread.sleep(3000);
		driver.findElement(By.id("signUpButton")).click();
		 Thread.sleep(6000);
    //    driver.findElement(By.xpath("//img[@class='d-inline-block align-center']")).click();
   //     driver.findElement(By.xpath("//a[@class='linkText logout nav-link']")).click();
        driver.quit();
	    	}
}
	