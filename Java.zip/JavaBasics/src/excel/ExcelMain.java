package excel;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class ExcelMain {

	public static void main(String[] args) {
	
		ReadData readData = new ReadData();
		
		System.setProperty("webdriver.chrome.driver", "F:\\chrome\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("http://www.demoaut.com/");
		
		WebElement UserName = driver.findElement(By.name("userName"));
		WebElement PassWord = driver.findElement(By.name("password"));
		
		String filePath = System.getProperty("user.dir") +"\\src\\excel";
		
		readData.readExcel(filePath, "TestData.xlsx", "Login");
		
		UserName.sendKeys(readData.hashMap.get("UserName").toString());
		PassWord.sendKeys(readData.hashMap.get("PassWord").toString());
	}

}
