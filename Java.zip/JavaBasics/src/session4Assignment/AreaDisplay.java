package session4Assignment;

public class AreaDisplay {

	public static void main(String[] args) {
		AreaCalculate object = new AreaCalculate();
		object.getAreaOfCircle();
		object.getAreaOfRectangle();
		object.getAreaOfTriangle();

	}

}
