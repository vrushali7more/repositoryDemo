package session4Assignment;

import java.util.Scanner;

public class UserInputAssignment {

	public static void main(String[] args) {
	Scanner in = new Scanner(System.in);
		
		System.out.println("Enter first input");
		String a = in.next();
		
		System.out.println("Enter second input");
		String b = in.next();
		
		System.out.println("The output is :"+a+" "+b);
	}

}
