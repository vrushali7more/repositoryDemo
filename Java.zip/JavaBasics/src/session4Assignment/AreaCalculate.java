package session4Assignment;

import java.util.Scanner;

public class AreaCalculate {
	
	double radius,length ,width, base,height;
	double answer;
	
	Scanner in = new Scanner(System.in);
	
	public void getAreaOfCircle(){

		System.out.println("Enter radius :");
		radius= in.nextDouble();
		
		answer=22 * radius * radius/7;
		
		System.out.println("Area of Circle is : "+answer);
	}
	
	public void getAreaOfRectangle(){
		
		System.out.println("Enter length:");
		length=in.nextDouble();
		
		System.out.println("Enter width :");
		width=in.nextDouble();
		
		answer= length * width;
		
		System.out.println("Area of Rectangle is :"+answer);
	}
	
	public void getAreaOfTriangle(){
		System.out.println("Enter breadth to calculate :");
		base=in.nextDouble();
		
		System.out.println("Enter height to calculate :");
		height=in.nextDouble();
		
		answer= base * height/2;
		
		System.out.println("Area of Traingle is :"+answer);
	}

}
