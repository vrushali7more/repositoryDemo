package session2Assignment;

public class Multiplication {

	public static void getMulti(int x,int y){
		int c;
		int a=10;
		int b=20;
		
		
		c= a * b;
		System.out.println("Multiplication:"+c);
	}

	public static void main(String[] args) {
		
		
		getMulti(4,5);

	}


}
