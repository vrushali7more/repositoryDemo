package session2Assignment;

public class AverageOfArray {

	public static void main(String[] args) {
		int arr[] = {};
		int tot=0;
		
		for(int i=0; i<arr.length; i++) {
			tot = tot+arr[i];
		}
		
		double avg = tot/arr.length;
		
		System.out.println(avg);
	}

}
