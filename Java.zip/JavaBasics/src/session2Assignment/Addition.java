package session2Assignment;

public class Addition {
	
	public static void getAdd(int x,int y){
		int c;
		int a=10;
		int b=20;
		
		
		c= a + b;
		System.out.println("Addition:"+c);
	}

	public static void main(String[] args) {
		
		
		getAdd(0, 0);

	}

}
