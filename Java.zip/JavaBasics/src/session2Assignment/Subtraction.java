package session2Assignment;

public class Subtraction {

	public static void getSub(int x,int y){
		int c;
		int a=40;
		int b=20;
		
		
		c= a - b;
		System.out.println("Subtration:"+c);
	}

	public static void main(String[] args) {
		
		getSub(0,0);

	}


}
