package session2Assignment;

public class FactorialOfNumber {


		public static void getFactorial(int n,int f){
			int num=n;
			int fact = f;
			for(int i=1; i<= num; i++)
			{
				fact = fact * i;
			}	System.out.println("Factorial is:");
			System.out.println(fact);
		}

		public static void main(String[] args) {
			
			
			getFactorial(5,1);

		}

	
}
