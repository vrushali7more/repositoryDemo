package session2Assignment;

public class Division {

	public static void getDiv(int x,int y){
		int c;
		int a=60;
		int b=20;
		
		
		c= a / b;
		System.out.println("Division:"+c);
	}

	public static void main(String[] args) {
		
		
		getDiv(4,5);

	}


}
