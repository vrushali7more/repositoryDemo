package session2Assignment;

public class SmallestLargestNumber {

	public static void main(String[] args) {
		int numbers[]= {9,6,4,3,7,2,12,2,13,11,14,1,14,1};

		int smallest = numbers[0];
		int largest = numbers[0];
		
		for(int i=0 ;i<numbers.length; i++) {
			if(numbers[i]> largest)
				largest = numbers[i];
			if(numbers[i]< smallest)
				smallest =numbers[i];
		}
		System.out.println("largest:"+largest);
		System.out.println("smallest:"+smallest);
	}

}
