package seleniumPrograms;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class Login {

	public static void main(String[] args) throws InterruptedException {
		
		System.setProperty("webdriver.gecko.driver", "F:/gecko/geckodriver-v0.24.0-win64/geckodriver.exe");
		
		WebDriver driver = new FirefoxDriver();
		
		driver.get("http://www.demoaut.com/");
		
		WebElement userName = driver.findElement(By.name("userName"));
		
		userName.sendKeys("Vrushali");
		userName.clear();
		userName.sendKeys("mercury");
		
		driver.findElement(By.xpath("//input[@type = 'password']")).sendKeys("mercury");
		
	//	WebElement reg = driver.findElement(By.linkText("REGISTER"));
		
		WebElement reg = driver.findElement(By.partialLinkText("REG"));
		
		System.out.println(reg.getText());
		reg.click();
		
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("//input[@name = 'firstName']")).sendKeys("Vrushali");
		
		driver.findElement(By.xpath("//input[@name = 'lastName']")).sendKeys("More");
		
		driver.findElement(By.xpath("//input[@name = 'phone']")).sendKeys("9653648261");
		
		driver.findElement(By.xpath("//input[@name = 'userName']")).sendKeys("vrush7more@gmail.com");
		
		driver.findElement(By.xpath("//input[@name = 'address1']")).sendKeys("Sinhgad road");
		
		driver.findElement(By.xpath("//input[@name = 'address2']")).sendKeys("Pune-51");
		
		driver.findElement(By.xpath("//input[@name = 'city']")).sendKeys("Pune");
		
		driver.findElement(By.xpath("//input[@name = 'state']")).sendKeys("Maharashtra");
		
		driver.findElement(By.xpath("//input[@name = 'postalCode']")).sendKeys("411051");
		
		WebElement dropdown = driver.findElement(By.xpath("//select[@name = 'country']"));
		
		Select dropBox = new Select(dropdown);
		
		String defaultselect = dropBox.getFirstSelectedOption().getText();
		
		System.out.println(defaultselect);
		
		List<WebElement> countrySelect = dropBox.getOptions();
		
		for(int i=0 ; i<countrySelect.size(); i++)
		{
		//	countrySelect(i)
		}
		
		driver.findElement(By.xpath("//input[@name = 'email']")).sendKeys("demo");
		
		driver.findElement(By.xpath("//input[@name = 'password']")).sendKeys("demo");
		
		driver.findElement(By.xpath("//input[@name = 'oconfirmPassword']")).sendKeys("demo");
		
	//	driver.findElement(By.xpath("//input[@name = 'register']")).click();
				

	}

}
