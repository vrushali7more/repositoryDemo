package session1Assignment;

public class AreaOfSquare {

	public static void main(String[] args) {
		int side=2;
		int ans;
		
		ans= side * side;
		System.out.println("Area of square :"+ans);
	}

}
