package session1Assignment;

public class Division {

	public static void main(String[] args) {
		int a=80;
		int b=20;
		int c;
		
		c= a / b;
		
		System.out.println("Test :"+c);
	}

}
