package session1Assignment;

public class AreaOfCircle {

	public static void main(String[] args) {
	
		double r=2;
		double ans;
		
		ans=22 * r * r/7;
		System.out.println("Area of circle :"+ans);
	}

}
