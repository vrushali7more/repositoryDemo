package session1Assignment;

public class AreaOfTriangle {

	public static void main(String[] args) {
		double b=2;
		double h=4;
		double ans;
		
		ans= b * h/2;
		System.out.println("Area of triangle :"+ans);
	}

}
