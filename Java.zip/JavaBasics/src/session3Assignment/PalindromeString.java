package session3Assignment;

public class PalindromeString {

	public static void checkPalindromeString(){
		String str ="121" ,rev= ""; 
		int length= str.length();
		for(int i=length-1;i>= 0;i-- )
		{
			rev = rev + str.charAt(i);
		}
		if(str.equals(rev))
			System.out.println(str +" string is a palindrome." );
		else
			System.out.println(str +" string is not a palindrome" );
	}

	public static void main(String[] args) {
		
		
		checkPalindromeString();
	}


}
