package session3Assignment;

public class ArmstrongNumber {

	public static void checkArmstrongNumber(){
		int num=1 ,number,temp,total=0;
		number =num;
		
		while(number != 0)
		{
			temp = number % 10;
			number= number/10;
			total = total + temp* temp * temp;
			
			
		}
		
		if(total == num)
			System.out.println(num + " is an Armstrong number");
		else
			System.out.println( num + " is not an Armstrong number");
	}

	public static void main(String[] args) {
		
		
		checkArmstrongNumber();

	}


}
