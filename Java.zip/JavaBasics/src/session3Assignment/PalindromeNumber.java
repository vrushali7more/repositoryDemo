package session3Assignment;

public class PalindromeNumber {

	public static void checkPalindromeNumber(){
		int remainder,sum =0,temp; 
		int num=121;
		temp = num;
		while(num > 0)
		{
			remainder = num% 10;
			sum =(sum*10) + remainder;
			num = num / 10;
		}
		if(temp == sum)
			System.out.println(temp + " is a palindrome number.");
		else
			System.out.println(temp + " is not a palindrome number");
		
	}

	public static void main(String[] args) {
		
		
		checkPalindromeNumber();
	}

}
