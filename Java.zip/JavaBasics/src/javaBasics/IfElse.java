package javaBasics;

public class IfElse {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int a = 51;
		
		if(a<=5) {
			System.out.println("A is a small no.");
		}
		else if(a>5 && a<=50) {
			
			System.out.println("A is a medium size no.");
		}
		
		else {
			System.out.println("A is a large no.");
		}
		
		
	}
	
	

}